<?
	require_once "functions/codes.php";
	
	$logdir = "/home/kevburns/eggdrop/logs/";
	$baseurl = "/recesslogs";

?>
<html>
    <head>
        <title>#Recess on irc.Freenode.net</title>
    </head>
    <body bgcolor="black" text="white">
<?
	$logdate = $_REQUEST['date'];
	$lines = file($logdir.'recess.log.'.$logdate);
	if(empty($lines)) {
		$files = scandir($logdir);
		foreach($files as $file) {
			if(strpos($file, 'recess.log') > -1) {
				$filedate = substr($file, 11);
				echo "<a href='".$baseurl."/".$filedate.".html'>".$filedate."</a><br />";
			}
		}
	} else {
		echo "<a href='".$baseurl."'>back</a><br />";
		foreach ($lines as $line_num => $line) {
			echo irc_color_codes($line);
			echo "<br>\n";
	    }
	}
?>
    </body>
</html>

